package com.mj.model;

public class Student extends Person {

	public Student(int age, float height, String name) {
		super(age, height, name);
		// TODO Auto-generated constructor stub
	}

}
